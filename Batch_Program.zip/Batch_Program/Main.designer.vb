﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Main))
        Me.chkPres = New System.Windows.Forms.CheckBox()
        Me.chkDerived = New System.Windows.Forms.CheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnOK = New System.Windows.Forms.Button()
        Me.chkDwgClose = New System.Windows.Forms.CheckBox()
        Me.chkDwgExport = New System.Windows.Forms.CheckBox()
        Me.chkDXF = New System.Windows.Forms.CheckBox()
        Me.chkPrint = New System.Windows.Forms.CheckBox()
        Me.chkEditRev = New System.Windows.Forms.CheckBox()
        Me.chkOpen = New System.Windows.Forms.CheckBox()
        Me.chkiProp = New System.Windows.Forms.CheckBox()
        Me.chkAssy = New System.Windows.Forms.CheckBox()
        Me.chkParts = New System.Windows.Forms.CheckBox()
        Me.chkDrawings = New System.Windows.Forms.CheckBox()
        Me.gbxSelection = New System.Windows.Forms.GroupBox()
        Me.gbxOpen = New System.Windows.Forms.GroupBox()
        Me.dgvOpenFiles = New System.Windows.Forms.DataGridView()
        Me.chkOpenFiles = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.PartName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PartSource = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PartLocation = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PartOrder = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.chkPartSelect = New System.Windows.Forms.CheckBox()
        Me.gbxDrawings = New System.Windows.Forms.GroupBox()
        Me.chkUseDrawings = New System.Windows.Forms.CheckBox()
        Me.chkFlatPattern = New System.Windows.Forms.CheckBox()
        Me.chkSkipAssy = New System.Windows.Forms.CheckBox()
        Me.ChkRevType = New System.Windows.Forms.CheckBox()
        Me.chkDWG = New System.Windows.Forms.CheckBox()
        Me.chkPDF = New System.Windows.Forms.CheckBox()
        Me.btnRename = New System.Windows.Forms.Button()
        Me.btnSpreadsheet = New System.Windows.Forms.Button()
        Me.gbxSub = New System.Windows.Forms.GroupBox()
        Me.txtSearch = New System.Windows.Forms.TextBox()
        Me.dgvSubFiles = New System.Windows.Forms.DataGridView()
        Me.chkSubFiles = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.DrawingName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DrawingNameAlpha = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DrawingSource = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DrawingLocation = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Comments = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Order = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CMSSubFiles = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.SortToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CMSAlphabetical = New System.Windows.Forms.ToolStripMenuItem()
        Me.CMSHeirarchical = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowHideToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CMSMissingDWG = New System.Windows.Forms.ToolStripMenuItem()
        Me.CMSMissingParts = New System.Windows.Forms.ToolStripMenuItem()
        Me.CMSReference = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExportToToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CMSSubSpreadsheet = New System.Windows.Forms.ToolStripMenuItem()
        Me.CMSSubText = New System.Windows.Forms.ToolStripMenuItem()
        Me.chkDWGSelect = New System.Windows.Forms.CheckBox()
        Me.tmr = New System.Windows.Forms.Timer(Me.components)
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.btnRef = New System.Windows.Forms.Button()
        Me.chkPartClose = New System.Windows.Forms.CheckBox()
        Me.chkPartUseDwg = New System.Windows.Forms.CheckBox()
        Me.chkPartSkip = New System.Windows.Forms.CheckBox()
        Me.chkPartExport = New System.Windows.Forms.CheckBox()
        Me.chkPartDXF = New System.Windows.Forms.CheckBox()
        Me.chkPartOpen = New System.Windows.Forms.CheckBox()
        Me.btnCreateDwg = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.gbxUtilities = New System.Windows.Forms.GroupBox()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DefaultSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RevTableSettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutBatchProgramToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuActDeact = New System.Windows.Forms.ToolStripMenuItem()
        Me.HowToToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.IFoundABugToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TutorialsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DebugLogToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.gbxParts = New System.Windows.Forms.GroupBox()
        Me.chkPartDWG = New System.Windows.Forms.CheckBox()
        Me.bgwUpdateSub = New System.ComponentModel.BackgroundWorker()
        Me.bgwUpdateOpen = New System.ComponentModel.BackgroundWorker()
        Me.bgwRun = New System.ComponentModel.BackgroundWorker()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pgbMain = New MSVistaProgressBar()
        Me.gbxSelection.SuspendLayout()
        Me.gbxOpen.SuspendLayout()
        CType(Me.dgvOpenFiles, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbxDrawings.SuspendLayout()
        Me.gbxSub.SuspendLayout()
        CType(Me.dgvSubFiles, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.CMSSubFiles.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.gbxUtilities.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.gbxParts.SuspendLayout()
        Me.SuspendLayout()
        '
        'chkPres
        '
        Me.chkPres.AutoSize = True
        Me.chkPres.Location = New System.Drawing.Point(6, 60)
        Me.chkPres.Name = "chkPres"
        Me.chkPres.Size = New System.Drawing.Size(90, 17)
        Me.chkPres.TabIndex = 49
        Me.chkPres.Text = "Presentations"
        Me.ToolTip1.SetToolTip(Me.chkPres, "Show the presentations that are currently open")
        Me.chkPres.UseVisualStyleBackColor = True
        '
        'chkDerived
        '
        Me.chkDerived.AutoSize = True
        Me.chkDerived.Location = New System.Drawing.Point(24, 45)
        Me.chkDerived.Name = "chkDerived"
        Me.chkDerived.Size = New System.Drawing.Size(101, 17)
        Me.chkDerived.TabIndex = 47
        Me.chkDerived.Text = "Multi-body Parts"
        Me.ToolTip1.SetToolTip(Me.chkDerived, "Display parts with derived components in the Referenced Drawing window")
        Me.chkDerived.UseVisualStyleBackColor = True
        Me.chkDerived.Visible = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Enabled = False
        Me.Label3.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label3.Location = New System.Drawing.Point(53, 64)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 13)
        Me.Label3.TabIndex = 46
        Me.Label3.Text = "Print Copies"
        '
        'btnExit
        '
        Me.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnExit.Location = New System.Drawing.Point(567, 246)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 45
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnOK
        '
        Me.btnOK.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnOK.Location = New System.Drawing.Point(648, 246)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(75, 23)
        Me.btnOK.TabIndex = 44
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'chkDwgClose
        '
        Me.chkDwgClose.AutoSize = True
        Me.chkDwgClose.Location = New System.Drawing.Point(6, 90)
        Me.chkDwgClose.Name = "chkDwgClose"
        Me.chkDwgClose.Size = New System.Drawing.Size(128, 17)
        Me.chkDwgClose.TabIndex = 43
        Me.chkDwgClose.Text = "Close Open Drawings"
        Me.ToolTip1.SetToolTip(Me.chkDwgClose, "Close all the drawings selected")
        Me.chkDwgClose.UseVisualStyleBackColor = True
        '
        'chkDwgExport
        '
        Me.chkDwgExport.AutoSize = True
        Me.chkDwgExport.Location = New System.Drawing.Point(6, 75)
        Me.chkDwgExport.Name = "chkDwgExport"
        Me.chkDwgExport.Size = New System.Drawing.Size(98, 17)
        Me.chkDwgExport.TabIndex = 42
        Me.chkDwgExport.Text = "Export Drawing"
        Me.ToolTip1.SetToolTip(Me.chkDwgExport, "Create PDF's of the drawings selected")
        Me.chkDwgExport.UseVisualStyleBackColor = True
        '
        'chkDXF
        '
        Me.chkDXF.AutoSize = True
        Me.chkDXF.Location = New System.Drawing.Point(109, 91)
        Me.chkDXF.Name = "chkDXF"
        Me.chkDXF.Size = New System.Drawing.Size(47, 17)
        Me.chkDXF.TabIndex = 41
        Me.chkDXF.Text = "DXF"
        Me.ToolTip1.SetToolTip(Me.chkDXF, "Create DXF's of the drawings selected")
        Me.chkDXF.UseVisualStyleBackColor = True
        Me.chkDXF.Visible = False
        '
        'chkPrint
        '
        Me.chkPrint.AutoSize = True
        Me.chkPrint.Location = New System.Drawing.Point(6, 45)
        Me.chkPrint.Name = "chkPrint"
        Me.chkPrint.Size = New System.Drawing.Size(94, 17)
        Me.chkPrint.TabIndex = 40
        Me.chkPrint.Text = "Print Drawings"
        Me.ToolTip1.SetToolTip(Me.chkPrint, "Print the drawings selected")
        Me.chkPrint.UseVisualStyleBackColor = True
        '
        'chkEditRev
        '
        Me.chkEditRev.AutoSize = True
        Me.chkEditRev.Location = New System.Drawing.Point(6, 30)
        Me.chkEditRev.Name = "chkEditRev"
        Me.chkEditRev.Size = New System.Drawing.Size(93, 17)
        Me.chkEditRev.TabIndex = 39
        Me.chkEditRev.Text = "Edit Revisions"
        Me.ToolTip1.SetToolTip(Me.chkEditRev, "Check the revision tables of the drawings selected")
        Me.chkEditRev.UseVisualStyleBackColor = True
        '
        'chkOpen
        '
        Me.chkOpen.AutoSize = True
        Me.chkOpen.Location = New System.Drawing.Point(6, 15)
        Me.chkOpen.Name = "chkOpen"
        Me.chkOpen.Size = New System.Drawing.Size(94, 17)
        Me.chkOpen.TabIndex = 38
        Me.chkOpen.Text = "Open Drawing"
        Me.ToolTip1.SetToolTip(Me.chkOpen, "Open all the drawings selected")
        Me.chkOpen.UseVisualStyleBackColor = True
        '
        'chkiProp
        '
        Me.chkiProp.AutoSize = True
        Me.chkiProp.Location = New System.Drawing.Point(564, 27)
        Me.chkiProp.Name = "chkiProp"
        Me.chkiProp.Size = New System.Drawing.Size(115, 17)
        Me.chkiProp.TabIndex = 37
        Me.chkiProp.Text = "Change iProperties"
        Me.ToolTip1.SetToolTip(Me.chkiProp, "Modify the iProperties on all the drawings selected")
        Me.chkiProp.UseVisualStyleBackColor = True
        '
        'chkAssy
        '
        Me.chkAssy.AutoSize = True
        Me.chkAssy.Location = New System.Drawing.Point(6, 45)
        Me.chkAssy.Name = "chkAssy"
        Me.chkAssy.Size = New System.Drawing.Size(78, 17)
        Me.chkAssy.TabIndex = 36
        Me.chkAssy.Text = "Assemblies"
        Me.ToolTip1.SetToolTip(Me.chkAssy, "Show the assemblies that are currently open")
        Me.chkAssy.UseVisualStyleBackColor = True
        '
        'chkParts
        '
        Me.chkParts.AutoSize = True
        Me.chkParts.Location = New System.Drawing.Point(6, 30)
        Me.chkParts.Name = "chkParts"
        Me.chkParts.Size = New System.Drawing.Size(50, 17)
        Me.chkParts.TabIndex = 35
        Me.chkParts.Text = "Parts"
        Me.ToolTip1.SetToolTip(Me.chkParts, "Show the parts that are currently open")
        Me.chkParts.UseVisualStyleBackColor = True
        '
        'chkDrawings
        '
        Me.chkDrawings.AutoSize = True
        Me.chkDrawings.Location = New System.Drawing.Point(6, 15)
        Me.chkDrawings.Name = "chkDrawings"
        Me.chkDrawings.Size = New System.Drawing.Size(70, 17)
        Me.chkDrawings.TabIndex = 34
        Me.chkDrawings.Text = "Drawings"
        Me.ToolTip1.SetToolTip(Me.chkDrawings, "Show the drawings that are currently open")
        Me.chkDrawings.UseVisualStyleBackColor = True
        '
        'gbxSelection
        '
        Me.gbxSelection.Controls.Add(Me.chkDerived)
        Me.gbxSelection.Controls.Add(Me.chkPres)
        Me.gbxSelection.Controls.Add(Me.chkAssy)
        Me.gbxSelection.Controls.Add(Me.chkParts)
        Me.gbxSelection.Controls.Add(Me.chkDrawings)
        Me.gbxSelection.Location = New System.Drawing.Point(12, 27)
        Me.gbxSelection.Name = "gbxSelection"
        Me.gbxSelection.Size = New System.Drawing.Size(142, 79)
        Me.gbxSelection.TabIndex = 50
        Me.gbxSelection.TabStop = False
        Me.gbxSelection.Text = "Selection"
        '
        'gbxOpen
        '
        Me.gbxOpen.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.gbxOpen.Controls.Add(Me.dgvOpenFiles)
        Me.gbxOpen.Controls.Add(Me.chkPartSelect)
        Me.gbxOpen.Location = New System.Drawing.Point(160, 27)
        Me.gbxOpen.Name = "gbxOpen"
        Me.gbxOpen.Size = New System.Drawing.Size(191, 205)
        Me.gbxOpen.TabIndex = 51
        Me.gbxOpen.TabStop = False
        Me.gbxOpen.Text = "      Open Parts"
        '
        'dgvOpenFiles
        '
        Me.dgvOpenFiles.AllowUserToAddRows = False
        Me.dgvOpenFiles.AllowUserToDeleteRows = False
        Me.dgvOpenFiles.AllowUserToResizeColumns = False
        Me.dgvOpenFiles.AllowUserToResizeRows = False
        Me.dgvOpenFiles.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgvOpenFiles.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.dgvOpenFiles.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        Me.dgvOpenFiles.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvOpenFiles.ColumnHeadersHeight = 17
        Me.dgvOpenFiles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvOpenFiles.ColumnHeadersVisible = False
        Me.dgvOpenFiles.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.chkOpenFiles, Me.PartName, Me.PartSource, Me.PartLocation, Me.PartOrder})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvOpenFiles.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgvOpenFiles.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.dgvOpenFiles.EnableHeadersVisualStyles = False
        Me.dgvOpenFiles.GridColor = System.Drawing.SystemColors.Window
        Me.dgvOpenFiles.Location = New System.Drawing.Point(10, 15)
        Me.dgvOpenFiles.Name = "dgvOpenFiles"
        Me.dgvOpenFiles.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        Me.dgvOpenFiles.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgvOpenFiles.RowHeadersVisible = False
        Me.dgvOpenFiles.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.ControlText
        Me.dgvOpenFiles.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.dgvOpenFiles.RowTemplate.Height = 17
        Me.dgvOpenFiles.RowTemplate.ReadOnly = True
        Me.dgvOpenFiles.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvOpenFiles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvOpenFiles.ShowCellToolTips = False
        Me.dgvOpenFiles.ShowEditingIcon = False
        Me.dgvOpenFiles.ShowRowErrors = False
        Me.dgvOpenFiles.Size = New System.Drawing.Size(175, 185)
        Me.dgvOpenFiles.TabIndex = 66
        '
        'chkOpenFiles
        '
        Me.chkOpenFiles.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.chkOpenFiles.FalseValue = "0"
        Me.chkOpenFiles.FillWeight = 12.69036!
        Me.chkOpenFiles.HeaderText = "chkOpenFiles"
        Me.chkOpenFiles.MinimumWidth = 17
        Me.chkOpenFiles.Name = "chkOpenFiles"
        Me.chkOpenFiles.ReadOnly = True
        Me.chkOpenFiles.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.chkOpenFiles.TrueValue = "1"
        '
        'PartName
        '
        Me.PartName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.PartName.FillWeight = 121.8274!
        Me.PartName.HeaderText = "Part Name"
        Me.PartName.MinimumWidth = 15
        Me.PartName.Name = "PartName"
        Me.PartName.ReadOnly = True
        Me.PartName.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        '
        'PartSource
        '
        Me.PartSource.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.PartSource.FillWeight = 121.8274!
        Me.PartSource.HeaderText = "Part Source"
        Me.PartSource.Name = "PartSource"
        Me.PartSource.ReadOnly = True
        Me.PartSource.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.PartSource.Visible = False
        '
        'PartLocation
        '
        Me.PartLocation.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.PartLocation.FillWeight = 121.8274!
        Me.PartLocation.HeaderText = "Part Location"
        Me.PartLocation.Name = "PartLocation"
        Me.PartLocation.ReadOnly = True
        Me.PartLocation.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.PartLocation.Visible = False
        '
        'PartOrder
        '
        Me.PartOrder.HeaderText = "Order"
        Me.PartOrder.Name = "PartOrder"
        Me.PartOrder.ReadOnly = True
        Me.PartOrder.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.PartOrder.Visible = False
        '
        'chkPartSelect
        '
        Me.chkPartSelect.AutoSize = True
        Me.chkPartSelect.Location = New System.Drawing.Point(10, 0)
        Me.chkPartSelect.Name = "chkPartSelect"
        Me.chkPartSelect.Size = New System.Drawing.Size(15, 14)
        Me.chkPartSelect.TabIndex = 1
        Me.chkPartSelect.UseVisualStyleBackColor = True
        '
        'gbxDrawings
        '
        Me.gbxDrawings.Controls.Add(Me.chkUseDrawings)
        Me.gbxDrawings.Controls.Add(Me.chkFlatPattern)
        Me.gbxDrawings.Controls.Add(Me.chkDwgClose)
        Me.gbxDrawings.Controls.Add(Me.chkSkipAssy)
        Me.gbxDrawings.Controls.Add(Me.chkDwgExport)
        Me.gbxDrawings.Controls.Add(Me.chkDXF)
        Me.gbxDrawings.Controls.Add(Me.ChkRevType)
        Me.gbxDrawings.Controls.Add(Me.chkDWG)
        Me.gbxDrawings.Controls.Add(Me.chkPDF)
        Me.gbxDrawings.Controls.Add(Me.Label3)
        Me.gbxDrawings.Controls.Add(Me.chkPrint)
        Me.gbxDrawings.Controls.Add(Me.chkEditRev)
        Me.gbxDrawings.Controls.Add(Me.chkOpen)
        Me.gbxDrawings.Location = New System.Drawing.Point(554, 119)
        Me.gbxDrawings.Name = "gbxDrawings"
        Me.gbxDrawings.Size = New System.Drawing.Size(176, 122)
        Me.gbxDrawings.TabIndex = 53
        Me.gbxDrawings.TabStop = False
        Me.gbxDrawings.Text = "Drawing Action"
        '
        'chkUseDrawings
        '
        Me.chkUseDrawings.AutoSize = True
        Me.chkUseDrawings.Location = New System.Drawing.Point(21, 136)
        Me.chkUseDrawings.Name = "chkUseDrawings"
        Me.chkUseDrawings.Size = New System.Drawing.Size(92, 17)
        Me.chkUseDrawings.TabIndex = 62
        Me.chkUseDrawings.Text = "Use Drawings"
        Me.ToolTip1.SetToolTip(Me.chkUseDrawings, "Create DXF's from the drawing.")
        Me.chkUseDrawings.UseVisualStyleBackColor = True
        Me.chkUseDrawings.Visible = False
        '
        'chkFlatPattern
        '
        Me.chkFlatPattern.AutoSize = True
        Me.chkFlatPattern.Checked = True
        Me.chkFlatPattern.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkFlatPattern.Location = New System.Drawing.Point(21, 121)
        Me.chkFlatPattern.Name = "chkFlatPattern"
        Me.chkFlatPattern.Size = New System.Drawing.Size(142, 17)
        Me.chkFlatPattern.TabIndex = 63
        Me.chkFlatPattern.Text = "Export Flat Patterns Only"
        Me.chkFlatPattern.UseVisualStyleBackColor = True
        Me.chkFlatPattern.Visible = False
        '
        'chkSkipAssy
        '
        Me.chkSkipAssy.AutoSize = True
        Me.chkSkipAssy.Location = New System.Drawing.Point(21, 106)
        Me.chkSkipAssy.Name = "chkSkipAssy"
        Me.chkSkipAssy.Size = New System.Drawing.Size(102, 17)
        Me.chkSkipAssy.TabIndex = 36
        Me.chkSkipAssy.Text = "Skip Assemblies"
        Me.ToolTip1.SetToolTip(Me.chkSkipAssy, "Do not make a DXF of the assemby")
        Me.chkSkipAssy.UseVisualStyleBackColor = True
        Me.chkSkipAssy.Visible = False
        '
        'ChkRevType
        '
        Me.ChkRevType.AutoSize = True
        Me.ChkRevType.Location = New System.Drawing.Point(6, 60)
        Me.ChkRevType.Name = "ChkRevType"
        Me.ChkRevType.Size = New System.Drawing.Size(113, 17)
        Me.ChkRevType.TabIndex = 59
        Me.ChkRevType.Text = "Change Rev Type"
        Me.ChkRevType.UseVisualStyleBackColor = True
        '
        'chkDWG
        '
        Me.chkDWG.AutoSize = True
        Me.chkDWG.Location = New System.Drawing.Point(58, 91)
        Me.chkDWG.Name = "chkDWG"
        Me.chkDWG.Size = New System.Drawing.Size(53, 17)
        Me.chkDWG.TabIndex = 58
        Me.chkDWG.Text = "DWG"
        Me.chkDWG.UseVisualStyleBackColor = True
        Me.chkDWG.Visible = False
        '
        'chkPDF
        '
        Me.chkPDF.AutoSize = True
        Me.chkPDF.Location = New System.Drawing.Point(13, 91)
        Me.chkPDF.Name = "chkPDF"
        Me.chkPDF.Size = New System.Drawing.Size(47, 17)
        Me.chkPDF.TabIndex = 57
        Me.chkPDF.Text = "PDF"
        Me.chkPDF.UseVisualStyleBackColor = True
        Me.chkPDF.Visible = False
        '
        'btnRename
        '
        Me.btnRename.Location = New System.Drawing.Point(6, 65)
        Me.btnRename.Name = "btnRename"
        Me.btnRename.Size = New System.Drawing.Size(130, 23)
        Me.btnRename.TabIndex = 2
        Me.btnRename.Text = "Rename Parts"
        Me.ToolTip1.SetToolTip(Me.btnRename, "Rename the components of a selected assembly")
        Me.btnRename.UseVisualStyleBackColor = True
        '
        'btnSpreadsheet
        '
        Me.btnSpreadsheet.Location = New System.Drawing.Point(6, 15)
        Me.btnSpreadsheet.Name = "btnSpreadsheet"
        Me.btnSpreadsheet.Size = New System.Drawing.Size(130, 23)
        Me.btnSpreadsheet.TabIndex = 0
        Me.btnSpreadsheet.Text = "Create Spreadsheet"
        Me.ToolTip1.SetToolTip(Me.btnSpreadsheet, "Create a spreadsheet of all the components of a selected assembly")
        Me.btnSpreadsheet.UseVisualStyleBackColor = True
        '
        'gbxSub
        '
        Me.gbxSub.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.gbxSub.Controls.Add(Me.txtSearch)
        Me.gbxSub.Controls.Add(Me.dgvSubFiles)
        Me.gbxSub.Controls.Add(Me.chkDWGSelect)
        Me.gbxSub.Cursor = System.Windows.Forms.Cursors.Default
        Me.gbxSub.Location = New System.Drawing.Point(357, 27)
        Me.gbxSub.Name = "gbxSub"
        Me.gbxSub.Size = New System.Drawing.Size(191, 205)
        Me.gbxSub.TabIndex = 52
        Me.gbxSub.TabStop = False
        Me.gbxSub.Text = "          Referenced Documents"
        '
        'txtSearch
        '
        Me.txtSearch.Location = New System.Drawing.Point(6, 179)
        Me.txtSearch.Name = "txtSearch"
        Me.txtSearch.Size = New System.Drawing.Size(178, 20)
        Me.txtSearch.TabIndex = 1
        Me.txtSearch.Visible = False
        '
        'dgvSubFiles
        '
        Me.dgvSubFiles.AllowUserToAddRows = False
        Me.dgvSubFiles.AllowUserToDeleteRows = False
        Me.dgvSubFiles.AllowUserToResizeColumns = False
        Me.dgvSubFiles.AllowUserToResizeRows = False
        Me.dgvSubFiles.BackgroundColor = System.Drawing.SystemColors.Window
        Me.dgvSubFiles.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.dgvSubFiles.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        Me.dgvSubFiles.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.dgvSubFiles.ColumnHeadersHeight = 17
        Me.dgvSubFiles.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing
        Me.dgvSubFiles.ColumnHeadersVisible = False
        Me.dgvSubFiles.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.chkSubFiles, Me.DrawingName, Me.DrawingNameAlpha, Me.DrawingSource, Me.DrawingLocation, Me.Comments, Me.Order})
        Me.dgvSubFiles.ContextMenuStrip = Me.CMSSubFiles
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvSubFiles.DefaultCellStyle = DataGridViewCellStyle6
        Me.dgvSubFiles.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.dgvSubFiles.EnableHeadersVisualStyles = False
        Me.dgvSubFiles.GridColor = System.Drawing.SystemColors.Window
        Me.dgvSubFiles.Location = New System.Drawing.Point(6, 16)
        Me.dgvSubFiles.MultiSelect = False
        Me.dgvSubFiles.Name = "dgvSubFiles"
        Me.dgvSubFiles.ReadOnly = True
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        Me.dgvSubFiles.RowHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.dgvSubFiles.RowHeadersVisible = False
        Me.dgvSubFiles.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.ControlText
        Me.dgvSubFiles.RowsDefaultCellStyle = DataGridViewCellStyle8
        Me.dgvSubFiles.RowTemplate.Height = 17
        Me.dgvSubFiles.RowTemplate.ReadOnly = True
        Me.dgvSubFiles.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvSubFiles.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvSubFiles.ShowCellToolTips = False
        Me.dgvSubFiles.ShowEditingIcon = False
        Me.dgvSubFiles.ShowRowErrors = False
        Me.dgvSubFiles.Size = New System.Drawing.Size(178, 184)
        Me.dgvSubFiles.TabIndex = 63
        '
        'chkSubFiles
        '
        Me.chkSubFiles.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.chkSubFiles.FalseValue = "0"
        Me.chkSubFiles.FillWeight = 12.69036!
        Me.chkSubFiles.HeaderText = "chkSubFiles"
        Me.chkSubFiles.MinimumWidth = 17
        Me.chkSubFiles.Name = "chkSubFiles"
        Me.chkSubFiles.ReadOnly = True
        Me.chkSubFiles.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.chkSubFiles.TrueValue = "1"
        '
        'DrawingName
        '
        Me.DrawingName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DrawingName.FillWeight = 121.8274!
        Me.DrawingName.HeaderText = "Drawing Name"
        Me.DrawingName.MinimumWidth = 15
        Me.DrawingName.Name = "DrawingName"
        Me.DrawingName.ReadOnly = True
        Me.DrawingName.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        '
        'DrawingNameAlpha
        '
        Me.DrawingNameAlpha.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DrawingNameAlpha.HeaderText = "Drawing Name Alpha"
        Me.DrawingNameAlpha.Name = "DrawingNameAlpha"
        Me.DrawingNameAlpha.ReadOnly = True
        Me.DrawingNameAlpha.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DrawingNameAlpha.Visible = False
        '
        'DrawingSource
        '
        Me.DrawingSource.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.DrawingSource.FillWeight = 121.8274!
        Me.DrawingSource.HeaderText = "Drawing Source"
        Me.DrawingSource.Name = "DrawingSource"
        Me.DrawingSource.ReadOnly = True
        Me.DrawingSource.Visible = False
        Me.DrawingSource.Width = 5
        '
        'DrawingLocation
        '
        Me.DrawingLocation.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.DrawingLocation.FillWeight = 121.8274!
        Me.DrawingLocation.HeaderText = "Drawing Location"
        Me.DrawingLocation.Name = "DrawingLocation"
        Me.DrawingLocation.ReadOnly = True
        Me.DrawingLocation.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DrawingLocation.Visible = False
        Me.DrawingLocation.Width = 5
        '
        'Comments
        '
        Me.Comments.FillWeight = 121.8274!
        Me.Comments.HeaderText = "Comments"
        Me.Comments.Name = "Comments"
        Me.Comments.ReadOnly = True
        Me.Comments.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Comments.Visible = False
        Me.Comments.Width = 43
        '
        'Order
        '
        Me.Order.HeaderText = "Order"
        Me.Order.Name = "Order"
        Me.Order.ReadOnly = True
        Me.Order.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Order.Visible = False
        '
        'CMSSubFiles
        '
        Me.CMSSubFiles.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SortToolStripMenuItem, Me.ShowHideToolStripMenuItem, Me.ExportToToolStripMenuItem})
        Me.CMSSubFiles.Name = "ContextMenuStrip1"
        Me.CMSSubFiles.Size = New System.Drawing.Size(153, 92)
        '
        'SortToolStripMenuItem
        '
        Me.SortToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CMSAlphabetical, Me.CMSHeirarchical})
        Me.SortToolStripMenuItem.Name = "SortToolStripMenuItem"
        Me.SortToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.SortToolStripMenuItem.Text = "Sort"
        '
        'CMSAlphabetical
        '
        Me.CMSAlphabetical.Name = "CMSAlphabetical"
        Me.CMSAlphabetical.Size = New System.Drawing.Size(152, 22)
        Me.CMSAlphabetical.Text = "Alphabetical"
        '
        'CMSHeirarchical
        '
        Me.CMSHeirarchical.Checked = True
        Me.CMSHeirarchical.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CMSHeirarchical.Name = "CMSHeirarchical"
        Me.CMSHeirarchical.Size = New System.Drawing.Size(152, 22)
        Me.CMSHeirarchical.Text = "Hierarchical"
        '
        'ShowHideToolStripMenuItem
        '
        Me.ShowHideToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CMSMissingDWG, Me.CMSMissingParts, Me.CMSReference})
        Me.ShowHideToolStripMenuItem.Name = "ShowHideToolStripMenuItem"
        Me.ShowHideToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ShowHideToolStripMenuItem.Text = "Show/Hide"
        '
        'CMSMissingDWG
        '
        Me.CMSMissingDWG.Name = "CMSMissingDWG"
        Me.CMSMissingDWG.Size = New System.Drawing.Size(206, 22)
        Me.CMSMissingDWG.Text = "Hide Missing Drawings"
        '
        'CMSMissingParts
        '
        Me.CMSMissingParts.Name = "CMSMissingParts"
        Me.CMSMissingParts.Size = New System.Drawing.Size(206, 22)
        Me.CMSMissingParts.Text = "Hide Missing Parts"
        '
        'CMSReference
        '
        Me.CMSReference.Name = "CMSReference"
        Me.CMSReference.Size = New System.Drawing.Size(206, 22)
        Me.CMSReference.Text = "Hide Reference Drawings"
        '
        'ExportToToolStripMenuItem
        '
        Me.ExportToToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CMSSubSpreadsheet, Me.CMSSubText})
        Me.ExportToToolStripMenuItem.Name = "ExportToToolStripMenuItem"
        Me.ExportToToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ExportToToolStripMenuItem.Text = "Export To"
        '
        'CMSSubSpreadsheet
        '
        Me.CMSSubSpreadsheet.Name = "CMSSubSpreadsheet"
        Me.CMSSubSpreadsheet.Size = New System.Drawing.Size(138, 22)
        Me.CMSSubSpreadsheet.Text = "Spreadsheet"
        '
        'CMSSubText
        '
        Me.CMSSubText.Name = "CMSSubText"
        Me.CMSSubText.Size = New System.Drawing.Size(138, 22)
        Me.CMSSubText.Text = "Text File"
        '
        'chkDWGSelect
        '
        Me.chkDWGSelect.AutoSize = True
        Me.chkDWGSelect.Checked = True
        Me.chkDWGSelect.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkDWGSelect.Location = New System.Drawing.Point(6, 0)
        Me.chkDWGSelect.Name = "chkDWGSelect"
        Me.chkDWGSelect.Size = New System.Drawing.Size(15, 14)
        Me.chkDWGSelect.TabIndex = 58
        Me.chkDWGSelect.UseVisualStyleBackColor = True
        '
        'ToolTip1
        '
        '
        'btnRef
        '
        Me.btnRef.Location = New System.Drawing.Point(6, 40)
        Me.btnRef.Name = "btnRef"
        Me.btnRef.Size = New System.Drawing.Size(130, 23)
        Me.btnRef.TabIndex = 3
        Me.btnRef.Text = "Update Ref Table"
        Me.ToolTip1.SetToolTip(Me.btnRef, "Add the parent drawing name to the Custom iProperties in each drawing")
        Me.btnRef.UseVisualStyleBackColor = True
        '
        'chkPartClose
        '
        Me.chkPartClose.AutoSize = True
        Me.chkPartClose.Location = New System.Drawing.Point(10, 46)
        Me.chkPartClose.Name = "chkPartClose"
        Me.chkPartClose.Size = New System.Drawing.Size(138, 17)
        Me.chkPartClose.TabIndex = 43
        Me.chkPartClose.Text = "Close Open Documents"
        Me.ToolTip1.SetToolTip(Me.chkPartClose, "Close all the drawings selected")
        Me.chkPartClose.UseVisualStyleBackColor = True
        '
        'chkPartUseDwg
        '
        Me.chkPartUseDwg.AutoSize = True
        Me.chkPartUseDwg.Location = New System.Drawing.Point(23, 78)
        Me.chkPartUseDwg.Name = "chkPartUseDwg"
        Me.chkPartUseDwg.Size = New System.Drawing.Size(92, 17)
        Me.chkPartUseDwg.TabIndex = 62
        Me.chkPartUseDwg.Text = "Use Drawings"
        Me.ToolTip1.SetToolTip(Me.chkPartUseDwg, "Create DXF's from the drawing.")
        Me.chkPartUseDwg.UseVisualStyleBackColor = True
        Me.chkPartUseDwg.Visible = False
        '
        'chkPartSkip
        '
        Me.chkPartSkip.AutoSize = True
        Me.chkPartSkip.Location = New System.Drawing.Point(23, 62)
        Me.chkPartSkip.Name = "chkPartSkip"
        Me.chkPartSkip.Size = New System.Drawing.Size(102, 17)
        Me.chkPartSkip.TabIndex = 36
        Me.chkPartSkip.Text = "Skip Assemblies"
        Me.ToolTip1.SetToolTip(Me.chkPartSkip, "Do not make a DXF of the assemby")
        Me.chkPartSkip.UseVisualStyleBackColor = True
        Me.chkPartSkip.Visible = False
        '
        'chkPartExport
        '
        Me.chkPartExport.AutoSize = True
        Me.chkPartExport.Location = New System.Drawing.Point(10, 30)
        Me.chkPartExport.Name = "chkPartExport"
        Me.chkPartExport.Size = New System.Drawing.Size(78, 17)
        Me.chkPartExport.TabIndex = 42
        Me.chkPartExport.Text = "Export Part"
        Me.ToolTip1.SetToolTip(Me.chkPartExport, "Create PDF's of the drawings selected")
        Me.chkPartExport.UseVisualStyleBackColor = True
        '
        'chkPartDXF
        '
        Me.chkPartDXF.AutoSize = True
        Me.chkPartDXF.Location = New System.Drawing.Point(77, 46)
        Me.chkPartDXF.Name = "chkPartDXF"
        Me.chkPartDXF.Size = New System.Drawing.Size(47, 17)
        Me.chkPartDXF.TabIndex = 41
        Me.chkPartDXF.Text = "DXF"
        Me.ToolTip1.SetToolTip(Me.chkPartDXF, "Create DXF's of the drawings selected")
        Me.chkPartDXF.UseVisualStyleBackColor = True
        Me.chkPartDXF.Visible = False
        '
        'chkPartOpen
        '
        Me.chkPartOpen.AutoSize = True
        Me.chkPartOpen.Location = New System.Drawing.Point(10, 15)
        Me.chkPartOpen.Name = "chkPartOpen"
        Me.chkPartOpen.Size = New System.Drawing.Size(74, 17)
        Me.chkPartOpen.TabIndex = 38
        Me.chkPartOpen.Text = "Open Part"
        Me.ToolTip1.SetToolTip(Me.chkPartOpen, "Open all the drawings selected")
        Me.chkPartOpen.UseVisualStyleBackColor = True
        '
        'btnCreateDwg
        '
        Me.btnCreateDwg.Location = New System.Drawing.Point(6, 91)
        Me.btnCreateDwg.Name = "btnCreateDwg"
        Me.btnCreateDwg.Size = New System.Drawing.Size(130, 23)
        Me.btnCreateDwg.TabIndex = 4
        Me.btnCreateDwg.Text = "Create Drawing"
        Me.ToolTip1.SetToolTip(Me.btnCreateDwg, "Create new drawings for selected referenced documents that are missing.")
        Me.btnCreateDwg.UseVisualStyleBackColor = True
        '
        'PictureBox2
        '
        Me.PictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PictureBox2.Image = Global.My.Resources.Resources.inverse1
        Me.PictureBox2.InitialImage = Nothing
        Me.PictureBox2.Location = New System.Drawing.Point(378, 27)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(15, 15)
        Me.PictureBox2.TabIndex = 59
        Me.PictureBox2.TabStop = False
        '
        'gbxUtilities
        '
        Me.gbxUtilities.Controls.Add(Me.btnCreateDwg)
        Me.gbxUtilities.Controls.Add(Me.btnRef)
        Me.gbxUtilities.Controls.Add(Me.btnRename)
        Me.gbxUtilities.Controls.Add(Me.btnSpreadsheet)
        Me.gbxUtilities.Cursor = System.Windows.Forms.Cursors.Default
        Me.gbxUtilities.Location = New System.Drawing.Point(12, 112)
        Me.gbxUtilities.Name = "gbxUtilities"
        Me.gbxUtilities.Size = New System.Drawing.Size(142, 120)
        Me.gbxUtilities.TabIndex = 60
        Me.gbxUtilities.TabStop = False
        Me.gbxUtilities.Text = "Experimental Utilities"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.AboutToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(746, 24)
        Me.MenuStrip1.TabIndex = 61
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DefaultSettingsToolStripMenuItem, Me.RevTableSettingsToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'DefaultSettingsToolStripMenuItem
        '
        Me.DefaultSettingsToolStripMenuItem.Name = "DefaultSettingsToolStripMenuItem"
        Me.DefaultSettingsToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.DefaultSettingsToolStripMenuItem.Text = "Export Settings"
        '
        'RevTableSettingsToolStripMenuItem
        '
        Me.RevTableSettingsToolStripMenuItem.Name = "RevTableSettingsToolStripMenuItem"
        Me.RevTableSettingsToolStripMenuItem.Size = New System.Drawing.Size(170, 22)
        Me.RevTableSettingsToolStripMenuItem.Text = "Rev Table Settings"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutBatchProgramToolStripMenuItem, Me.mnuActDeact, Me.HowToToolStripMenuItem1, Me.IFoundABugToolStripMenuItem, Me.TutorialsToolStripMenuItem, Me.DebugLogToolStripMenuItem})
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.AboutToolStripMenuItem.Text = "Help"
        '
        'AboutBatchProgramToolStripMenuItem
        '
        Me.AboutBatchProgramToolStripMenuItem.Name = "AboutBatchProgramToolStripMenuItem"
        Me.AboutBatchProgramToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.AboutBatchProgramToolStripMenuItem.Text = "About Batch Program"
        '
        'mnuActDeact
        '
        Me.mnuActDeact.Enabled = False
        Me.mnuActDeact.Name = "mnuActDeact"
        Me.mnuActDeact.Size = New System.Drawing.Size(189, 22)
        Me.mnuActDeact.Text = "Activate"
        '
        'HowToToolStripMenuItem1
        '
        Me.HowToToolStripMenuItem1.Name = "HowToToolStripMenuItem1"
        Me.HowToToolStripMenuItem1.Size = New System.Drawing.Size(189, 22)
        Me.HowToToolStripMenuItem1.Text = "Changelog"
        '
        'IFoundABugToolStripMenuItem
        '
        Me.IFoundABugToolStripMenuItem.Name = "IFoundABugToolStripMenuItem"
        Me.IFoundABugToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.IFoundABugToolStripMenuItem.Text = "I found a bug"
        '
        'TutorialsToolStripMenuItem
        '
        Me.TutorialsToolStripMenuItem.Enabled = False
        Me.TutorialsToolStripMenuItem.Name = "TutorialsToolStripMenuItem"
        Me.TutorialsToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.TutorialsToolStripMenuItem.Text = "Tutorials"
        '
        'DebugLogToolStripMenuItem
        '
        Me.DebugLogToolStripMenuItem.Name = "DebugLogToolStripMenuItem"
        Me.DebugLogToolStripMenuItem.Size = New System.Drawing.Size(189, 22)
        Me.DebugLogToolStripMenuItem.Text = "Debug Log"
        '
        'gbxParts
        '
        Me.gbxParts.Controls.Add(Me.chkPartClose)
        Me.gbxParts.Controls.Add(Me.chkPartUseDwg)
        Me.gbxParts.Controls.Add(Me.chkPartSkip)
        Me.gbxParts.Controls.Add(Me.chkPartExport)
        Me.gbxParts.Controls.Add(Me.chkPartDXF)
        Me.gbxParts.Controls.Add(Me.chkPartDWG)
        Me.gbxParts.Controls.Add(Me.chkPartOpen)
        Me.gbxParts.Location = New System.Drawing.Point(554, 48)
        Me.gbxParts.Name = "gbxParts"
        Me.gbxParts.Size = New System.Drawing.Size(176, 67)
        Me.gbxParts.TabIndex = 63
        Me.gbxParts.TabStop = False
        Me.gbxParts.Text = "Part Actions"
        '
        'chkPartDWG
        '
        Me.chkPartDWG.AutoSize = True
        Me.chkPartDWG.Location = New System.Drawing.Point(23, 46)
        Me.chkPartDWG.Name = "chkPartDWG"
        Me.chkPartDWG.Size = New System.Drawing.Size(53, 17)
        Me.chkPartDWG.TabIndex = 58
        Me.chkPartDWG.Text = "DWG"
        Me.chkPartDWG.UseVisualStyleBackColor = True
        Me.chkPartDWG.Visible = False
        '
        'bgwUpdateSub
        '
        Me.bgwUpdateSub.WorkerReportsProgress = True
        Me.bgwUpdateSub.WorkerSupportsCancellation = True
        '
        'bgwUpdateOpen
        '
        Me.bgwUpdateOpen.WorkerSupportsCancellation = True
        '
        'bgwRun
        '
        Me.bgwRun.WorkerSupportsCancellation = True
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn1.FillWeight = 121.8274!
        Me.DataGridViewTextBoxColumn1.HeaderText = "Part Name"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 15
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn2.FillWeight = 121.8274!
        Me.DataGridViewTextBoxColumn2.HeaderText = "Part Source"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn2.Visible = False
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn3.FillWeight = 121.8274!
        Me.DataGridViewTextBoxColumn3.HeaderText = "Part Location"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.ReadOnly = True
        Me.DataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn3.Visible = False
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.HeaderText = "Order"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn4.Visible = False
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn5.FillWeight = 121.8274!
        Me.DataGridViewTextBoxColumn5.HeaderText = "Drawing Name"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 15
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.DataGridViewTextBoxColumn6.HeaderText = "Drawing Name Alpha"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.ReadOnly = True
        Me.DataGridViewTextBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn6.Visible = False
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.DataGridViewTextBoxColumn7.FillWeight = 121.8274!
        Me.DataGridViewTextBoxColumn7.HeaderText = "Drawing Source"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn7.Visible = False
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.DisplayedCells
        Me.DataGridViewTextBoxColumn8.FillWeight = 121.8274!
        Me.DataGridViewTextBoxColumn8.HeaderText = "Drawing Location"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn8.Visible = False
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.FillWeight = 121.8274!
        Me.DataGridViewTextBoxColumn9.HeaderText = "Comments"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        Me.DataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn9.Visible = False
        Me.DataGridViewTextBoxColumn9.Width = 43
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.HeaderText = "Order"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        Me.DataGridViewTextBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn10.Visible = False
        '
        'pgbMain
        '
        Me.pgbMain.BackColor = System.Drawing.Color.Transparent
        Me.pgbMain.BlockSize = 10
        Me.pgbMain.BlockSpacing = 10
        Me.pgbMain.DisplayText = "%P%"
        Me.pgbMain.DisplayTextColor = System.Drawing.SystemColors.ControlText
        Me.pgbMain.DisplayTextFont = New System.Drawing.Font("Arial", 8.0!)
        Me.pgbMain.GradiantStyle = MSVistaProgressBar.BackGradiant.None
        Me.pgbMain.Location = New System.Drawing.Point(12, 247)
        Me.pgbMain.Name = "pgbMain"
        Me.pgbMain.ShowText = True
        Me.pgbMain.Size = New System.Drawing.Size(536, 23)
        Me.pgbMain.TabIndex = 62
        Me.pgbMain.Visible = False
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(746, 277)
        Me.Controls.Add(Me.gbxParts)
        Me.Controls.Add(Me.pgbMain)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.gbxDrawings)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.gbxSub)
        Me.Controls.Add(Me.gbxOpen)
        Me.Controls.Add(Me.gbxSelection)
        Me.Controls.Add(Me.gbxUtilities)
        Me.Controls.Add(Me.chkiProp)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MaximizeBox = False
        Me.MinimumSize = New System.Drawing.Size(762, 315)
        Me.Name = "Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Batch Program"
        Me.TransparencyKey = System.Drawing.Color.Maroon
        Me.gbxSelection.ResumeLayout(False)
        Me.gbxSelection.PerformLayout()
        Me.gbxOpen.ResumeLayout(False)
        Me.gbxOpen.PerformLayout()
        CType(Me.dgvOpenFiles, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbxDrawings.ResumeLayout(False)
        Me.gbxDrawings.PerformLayout()
        Me.gbxSub.ResumeLayout(False)
        Me.gbxSub.PerformLayout()
        CType(Me.dgvSubFiles, System.ComponentModel.ISupportInitialize).EndInit()
        Me.CMSSubFiles.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.gbxUtilities.ResumeLayout(False)
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.gbxParts.ResumeLayout(False)
        Me.gbxParts.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents chkPres As System.Windows.Forms.CheckBox
    Friend WithEvents chkDerived As System.Windows.Forms.CheckBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents chkDwgClose As System.Windows.Forms.CheckBox
    Friend WithEvents chkDwgExport As System.Windows.Forms.CheckBox
    Friend WithEvents chkDXF As System.Windows.Forms.CheckBox
    Friend WithEvents chkPrint As System.Windows.Forms.CheckBox
    Friend WithEvents chkEditRev As System.Windows.Forms.CheckBox
    Friend WithEvents chkOpen As System.Windows.Forms.CheckBox
    Friend WithEvents chkiProp As System.Windows.Forms.CheckBox
    Friend WithEvents chkAssy As System.Windows.Forms.CheckBox
    Friend WithEvents chkParts As System.Windows.Forms.CheckBox
    Friend WithEvents chkDrawings As System.Windows.Forms.CheckBox
    Friend WithEvents gbxSelection As System.Windows.Forms.GroupBox
    Friend WithEvents gbxOpen As System.Windows.Forms.GroupBox
    Friend WithEvents gbxDrawings As System.Windows.Forms.GroupBox
    Friend WithEvents chkSkipAssy As System.Windows.Forms.CheckBox
    Friend WithEvents btnRename As System.Windows.Forms.Button
    Friend WithEvents btnSpreadsheet As System.Windows.Forms.Button
    Friend WithEvents gbxSub As System.Windows.Forms.GroupBox
    Friend WithEvents tmr As System.Windows.Forms.Timer
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents pgbMain As MSVistaProgressBar
    Friend WithEvents txtSearch As System.Windows.Forms.TextBox
    Friend WithEvents chkDWG As Windows.Forms.CheckBox
    Friend WithEvents chkPDF As Windows.Forms.CheckBox
    Friend WithEvents chkPartSelect As Windows.Forms.CheckBox
    Friend WithEvents PictureBox2 As Windows.Forms.PictureBox
    Friend WithEvents chkDWGSelect As Windows.Forms.CheckBox
    Friend WithEvents ChkRevType As Windows.Forms.CheckBox
    Friend WithEvents gbxUtilities As Windows.Forms.GroupBox
    Friend WithEvents chkUseDrawings As Windows.Forms.CheckBox
    Friend WithEvents btnRef As Windows.Forms.Button
    Friend WithEvents CMSSubFiles As Windows.Forms.ContextMenuStrip
    Friend WithEvents SortAlphabeticallyToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents SortHierarchicallyToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents AlphabeticalToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents HierarchicalToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents SpreadsheetToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextFileToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents SortToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents AlphabeticalToolStripMenuItem1 As Windows.Forms.ToolStripMenuItem
    Friend WithEvents HeirarchicalToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents SpreadsheetToolStripMenuItem1 As Windows.Forms.ToolStripMenuItem
    Friend WithEvents TextFileToolStripMenuItem1 As Windows.Forms.ToolStripMenuItem
    Friend WithEvents CMSAlphabetical As Windows.Forms.ToolStripMenuItem
    Friend WithEvents CMSHeirarchical As Windows.Forms.ToolStripMenuItem
    Friend WithEvents ShowHideToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents CMSMissingDWG As Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuStrip1 As Windows.Forms.MenuStrip
    Friend WithEvents FileToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents DefaultSettingsToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents AboutBatchProgramToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuActDeact As Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExportToToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents CMSSubSpreadsheet As Windows.Forms.ToolStripMenuItem
    Friend WithEvents CMSSubText As Windows.Forms.ToolStripMenuItem
    Friend WithEvents HowToToolStripMenuItem1 As Windows.Forms.ToolStripMenuItem
    Friend WithEvents CMSReference As Windows.Forms.ToolStripMenuItem
    Friend WithEvents IFoundABugToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents CMSMissingParts As Windows.Forms.ToolStripMenuItem
    Friend WithEvents TutorialsToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents RevTableSettingsToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents dgvSubFiles As Windows.Forms.DataGridView
    Friend WithEvents dgvOpenFiles As Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents gbxParts As Windows.Forms.GroupBox
    Friend WithEvents chkPartClose As Windows.Forms.CheckBox
    Friend WithEvents chkPartUseDwg As Windows.Forms.CheckBox
    Friend WithEvents chkPartSkip As Windows.Forms.CheckBox
    Friend WithEvents chkPartExport As Windows.Forms.CheckBox
    Friend WithEvents chkPartDXF As Windows.Forms.CheckBox
    Friend WithEvents chkPartDWG As Windows.Forms.CheckBox
    Friend WithEvents chkPartOpen As Windows.Forms.CheckBox
    Friend WithEvents bgwUpdateSub As ComponentModel.BackgroundWorker
    Friend WithEvents bgwUpdateOpen As ComponentModel.BackgroundWorker
    Friend WithEvents bgwRun As ComponentModel.BackgroundWorker
    Friend WithEvents chkFlatPattern As Windows.Forms.CheckBox
    Friend WithEvents DebugLogToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents chkOpenFiles As Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents PartName As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PartSource As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PartLocation As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PartOrder As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents chkSubFiles As Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents DrawingName As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DrawingNameAlpha As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DrawingSource As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DrawingLocation As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Comments As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Order As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnCreateDwg As Windows.Forms.Button
End Class
