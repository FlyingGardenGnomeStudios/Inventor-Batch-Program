﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class iProperties
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(iProperties))
        Me.btnOK = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.iProp = New System.Windows.Forms.TabControl()
        Me.Summary = New System.Windows.Forms.TabPage()
        Me.dgvSummary = New System.Windows.Forms.DataGridView()
        Me.SumItem = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SumModel = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SumDrawing = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SummaryIsDirty = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.Project = New System.Windows.Forms.TabPage()
        Me.dgvProject = New System.Windows.Forms.DataGridView()
        Me.ProjItem = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProjModel = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProjDrawing = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProjectIsDirty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Status = New System.Windows.Forms.TabPage()
        Me.dgvStatus = New System.Windows.Forms.DataGridView()
        Me.StatusItem = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StatusModel = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StatusDrawing = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.StatusIsDirty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Custom = New System.Windows.Forms.TabPage()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dgvCustomDrawing = New System.Windows.Forms.DataGridView()
        Me.DCusName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DCusValue = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DCusType = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.DrawingIsDirty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.dgvCustomModel = New System.Windows.Forms.DataGridView()
        Me.PCusName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PCusValue = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PCusType = New System.Windows.Forms.DataGridViewComboBoxColumn()
        Me.ModelIsDirty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RevisionTable = New System.Windows.Forms.TabPage()
        Me.RevisionTabs = New System.Windows.Forms.TabControl()
        Me.Rev1 = New System.Windows.Forms.TabPage()
        Me.btnAddRev = New System.Windows.Forms.Button()
        Me.dgvRev1 = New System.Windows.Forms.DataGridView()
        Me.Rev1Item = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Rev1Drawing = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Rev1IsDirty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.lblRev0 = New System.Windows.Forms.Label()
        Me.cmsCustom = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.RemoveIPropertyToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.ProgressBar2 = New System.Windows.Forms.ProgressBar()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn24 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn34 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn35 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn36 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn37 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.iProp.SuspendLayout()
        Me.Summary.SuspendLayout()
        CType(Me.dgvSummary, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Project.SuspendLayout()
        CType(Me.dgvProject, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Status.SuspendLayout()
        CType(Me.dgvStatus, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Custom.SuspendLayout()
        CType(Me.dgvCustomDrawing, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgvCustomModel, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.RevisionTable.SuspendLayout()
        Me.RevisionTabs.SuspendLayout()
        Me.Rev1.SuspendLayout()
        CType(Me.dgvRev1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.cmsCustom.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnOK
        '
        Me.btnOK.Location = New System.Drawing.Point(203, 442)
        Me.btnOK.Name = "btnOK"
        Me.btnOK.Size = New System.Drawing.Size(75, 23)
        Me.btnOK.TabIndex = 5
        Me.btnOK.Text = "OK"
        Me.btnOK.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(284, 442)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(75, 23)
        Me.btnCancel.TabIndex = 4
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'iProp
        '
        Me.iProp.Controls.Add(Me.Summary)
        Me.iProp.Controls.Add(Me.Project)
        Me.iProp.Controls.Add(Me.Status)
        Me.iProp.Controls.Add(Me.Custom)
        Me.iProp.Controls.Add(Me.RevisionTable)
        Me.iProp.Location = New System.Drawing.Point(12, 12)
        Me.iProp.Name = "iProp"
        Me.iProp.SelectedIndex = 0
        Me.iProp.Size = New System.Drawing.Size(347, 424)
        Me.iProp.TabIndex = 3
        Me.iProp.Tag = ""
        '
        'Summary
        '
        Me.Summary.BackColor = System.Drawing.Color.White
        Me.Summary.Controls.Add(Me.dgvSummary)
        Me.Summary.Location = New System.Drawing.Point(4, 22)
        Me.Summary.Name = "Summary"
        Me.Summary.Padding = New System.Windows.Forms.Padding(3)
        Me.Summary.Size = New System.Drawing.Size(339, 398)
        Me.Summary.TabIndex = 0
        Me.Summary.Text = "Summary"
        '
        'dgvSummary
        '
        Me.dgvSummary.AllowUserToAddRows = False
        Me.dgvSummary.AllowUserToDeleteRows = False
        Me.dgvSummary.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvSummary.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvSummary.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.SumItem, Me.SumModel, Me.SumDrawing, Me.SummaryIsDirty})
        Me.dgvSummary.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.dgvSummary.Location = New System.Drawing.Point(6, 6)
        Me.dgvSummary.Name = "dgvSummary"
        Me.dgvSummary.RowHeadersVisible = False
        Me.dgvSummary.Size = New System.Drawing.Size(326, 386)
        Me.dgvSummary.TabIndex = 16
        '
        'SumItem
        '
        Me.SumItem.HeaderText = "Item"
        Me.SumItem.Name = "SumItem"
        Me.SumItem.ReadOnly = True
        Me.SumItem.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.SumItem.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'SumModel
        '
        Me.SumModel.HeaderText = "Model"
        Me.SumModel.Name = "SumModel"
        Me.SumModel.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'SumDrawing
        '
        Me.SumDrawing.HeaderText = "Drawing"
        Me.SumDrawing.Name = "SumDrawing"
        Me.SumDrawing.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'SummaryIsDirty
        '
        Me.SummaryIsDirty.HeaderText = "IsDirty"
        Me.SummaryIsDirty.Name = "SummaryIsDirty"
        Me.SummaryIsDirty.ReadOnly = True
        Me.SummaryIsDirty.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.SummaryIsDirty.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        Me.SummaryIsDirty.Visible = False
        '
        'Project
        '
        Me.Project.Controls.Add(Me.dgvProject)
        Me.Project.Location = New System.Drawing.Point(4, 22)
        Me.Project.Name = "Project"
        Me.Project.Padding = New System.Windows.Forms.Padding(3)
        Me.Project.Size = New System.Drawing.Size(339, 398)
        Me.Project.TabIndex = 1
        Me.Project.Text = "Project"
        Me.Project.UseVisualStyleBackColor = True
        '
        'dgvProject
        '
        Me.dgvProject.AllowUserToAddRows = False
        Me.dgvProject.AllowUserToDeleteRows = False
        Me.dgvProject.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvProject.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvProject.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ProjItem, Me.ProjModel, Me.ProjDrawing, Me.ProjectIsDirty})
        Me.dgvProject.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.dgvProject.Location = New System.Drawing.Point(6, 6)
        Me.dgvProject.Name = "dgvProject"
        Me.dgvProject.RowHeadersVisible = False
        Me.dgvProject.Size = New System.Drawing.Size(326, 386)
        Me.dgvProject.TabIndex = 46
        '
        'ProjItem
        '
        Me.ProjItem.HeaderText = "Item"
        Me.ProjItem.Name = "ProjItem"
        Me.ProjItem.ReadOnly = True
        Me.ProjItem.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.ProjItem.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'ProjModel
        '
        Me.ProjModel.HeaderText = "Model"
        Me.ProjModel.Name = "ProjModel"
        '
        'ProjDrawing
        '
        Me.ProjDrawing.HeaderText = "Drawing"
        Me.ProjDrawing.Name = "ProjDrawing"
        '
        'ProjectIsDirty
        '
        Me.ProjectIsDirty.HeaderText = "IsDirty"
        Me.ProjectIsDirty.Name = "ProjectIsDirty"
        Me.ProjectIsDirty.Visible = False
        '
        'Status
        '
        Me.Status.Controls.Add(Me.dgvStatus)
        Me.Status.Location = New System.Drawing.Point(4, 22)
        Me.Status.Name = "Status"
        Me.Status.Padding = New System.Windows.Forms.Padding(3)
        Me.Status.Size = New System.Drawing.Size(339, 398)
        Me.Status.TabIndex = 2
        Me.Status.Text = "Status"
        Me.Status.UseVisualStyleBackColor = True
        '
        'dgvStatus
        '
        Me.dgvStatus.AllowUserToAddRows = False
        Me.dgvStatus.AllowUserToDeleteRows = False
        Me.dgvStatus.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvStatus.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvStatus.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.StatusItem, Me.StatusModel, Me.StatusDrawing, Me.StatusIsDirty})
        Me.dgvStatus.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.dgvStatus.Location = New System.Drawing.Point(6, 6)
        Me.dgvStatus.Name = "dgvStatus"
        Me.dgvStatus.RowHeadersVisible = False
        Me.dgvStatus.Size = New System.Drawing.Size(326, 386)
        Me.dgvStatus.TabIndex = 62
        '
        'StatusItem
        '
        Me.StatusItem.HeaderText = "Item"
        Me.StatusItem.Name = "StatusItem"
        Me.StatusItem.ReadOnly = True
        Me.StatusItem.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.StatusItem.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'StatusModel
        '
        Me.StatusModel.HeaderText = "Model"
        Me.StatusModel.Name = "StatusModel"
        '
        'StatusDrawing
        '
        Me.StatusDrawing.HeaderText = "Drawing"
        Me.StatusDrawing.Name = "StatusDrawing"
        '
        'StatusIsDirty
        '
        Me.StatusIsDirty.HeaderText = "IsDirty"
        Me.StatusIsDirty.Name = "StatusIsDirty"
        Me.StatusIsDirty.Visible = False
        '
        'Custom
        '
        Me.Custom.Controls.Add(Me.Label2)
        Me.Custom.Controls.Add(Me.Label1)
        Me.Custom.Controls.Add(Me.dgvCustomDrawing)
        Me.Custom.Controls.Add(Me.dgvCustomModel)
        Me.Custom.Location = New System.Drawing.Point(4, 22)
        Me.Custom.Name = "Custom"
        Me.Custom.Padding = New System.Windows.Forms.Padding(3)
        Me.Custom.Size = New System.Drawing.Size(339, 398)
        Me.Custom.TabIndex = 3
        Me.Custom.Text = "Custom"
        Me.Custom.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 203)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 13)
        Me.Label2.TabIndex = 59
        Me.Label2.Text = "Drawing Properties"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 13)
        Me.Label1.TabIndex = 58
        Me.Label1.Text = "Model Properties"
        '
        'dgvCustomDrawing
        '
        Me.dgvCustomDrawing.AllowUserToOrderColumns = True
        Me.dgvCustomDrawing.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvCustomDrawing.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvCustomDrawing.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DCusName, Me.DCusValue, Me.DCusType, Me.DrawingIsDirty})
        Me.dgvCustomDrawing.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.dgvCustomDrawing.Location = New System.Drawing.Point(6, 219)
        Me.dgvCustomDrawing.Name = "dgvCustomDrawing"
        Me.dgvCustomDrawing.RowHeadersVisible = False
        Me.dgvCustomDrawing.Size = New System.Drawing.Size(326, 173)
        Me.dgvCustomDrawing.TabIndex = 57
        '
        'DCusName
        '
        Me.DCusName.HeaderText = "Name"
        Me.DCusName.Name = "DCusName"
        Me.DCusName.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        '
        'DCusValue
        '
        Me.DCusValue.HeaderText = "Value"
        Me.DCusValue.Name = "DCusValue"
        '
        'DCusType
        '
        Me.DCusType.HeaderText = "Type"
        Me.DCusType.Items.AddRange(New Object() {"Text", "Date", "Number", "Yes or No"})
        Me.DCusType.Name = "DCusType"
        Me.DCusType.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.DCusType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'DrawingIsDirty
        '
        Me.DrawingIsDirty.HeaderText = "IsDirty"
        Me.DrawingIsDirty.Name = "DrawingIsDirty"
        Me.DrawingIsDirty.Visible = False
        '
        'dgvCustomModel
        '
        Me.dgvCustomModel.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvCustomModel.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvCustomModel.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.PCusName, Me.PCusValue, Me.PCusType, Me.ModelIsDirty})
        Me.dgvCustomModel.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.dgvCustomModel.Location = New System.Drawing.Point(6, 27)
        Me.dgvCustomModel.Name = "dgvCustomModel"
        Me.dgvCustomModel.RowHeadersVisible = False
        Me.dgvCustomModel.Size = New System.Drawing.Size(326, 173)
        Me.dgvCustomModel.TabIndex = 56
        '
        'PCusName
        '
        Me.PCusName.HeaderText = "Name"
        Me.PCusName.Name = "PCusName"
        Me.PCusName.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        '
        'PCusValue
        '
        Me.PCusValue.HeaderText = "Value"
        Me.PCusValue.Name = "PCusValue"
        '
        'PCusType
        '
        Me.PCusType.HeaderText = "Type"
        Me.PCusType.Items.AddRange(New Object() {"Text", "Date", "Number", "Yes or No"})
        Me.PCusType.Name = "PCusType"
        Me.PCusType.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.PCusType.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic
        '
        'ModelIsDirty
        '
        Me.ModelIsDirty.HeaderText = "IsDirty"
        Me.ModelIsDirty.Name = "ModelIsDirty"
        Me.ModelIsDirty.Visible = False
        '
        'RevisionTable
        '
        Me.RevisionTable.Controls.Add(Me.RevisionTabs)
        Me.RevisionTable.Location = New System.Drawing.Point(4, 22)
        Me.RevisionTable.Name = "RevisionTable"
        Me.RevisionTable.Padding = New System.Windows.Forms.Padding(3)
        Me.RevisionTable.Size = New System.Drawing.Size(339, 398)
        Me.RevisionTable.TabIndex = 4
        Me.RevisionTable.Text = "Revision Table"
        Me.RevisionTable.UseVisualStyleBackColor = True
        '
        'RevisionTabs
        '
        Me.RevisionTabs.Controls.Add(Me.Rev1)
        Me.RevisionTabs.Enabled = False
        Me.RevisionTabs.Location = New System.Drawing.Point(-4, 0)
        Me.RevisionTabs.Name = "RevisionTabs"
        Me.RevisionTabs.SelectedIndex = 0
        Me.RevisionTabs.Size = New System.Drawing.Size(347, 392)
        Me.RevisionTabs.TabIndex = 0
        Me.RevisionTabs.Visible = False
        '
        'Rev1
        '
        Me.Rev1.Controls.Add(Me.btnAddRev)
        Me.Rev1.Controls.Add(Me.dgvRev1)
        Me.Rev1.Controls.Add(Me.lblRev0)
        Me.Rev1.Location = New System.Drawing.Point(4, 22)
        Me.Rev1.Name = "Rev1"
        Me.Rev1.Padding = New System.Windows.Forms.Padding(3)
        Me.Rev1.Size = New System.Drawing.Size(339, 366)
        Me.Rev1.TabIndex = 0
        Me.Rev1.Text = "Rev 1"
        Me.Rev1.UseVisualStyleBackColor = True
        '
        'btnAddRev
        '
        Me.btnAddRev.Location = New System.Drawing.Point(258, 337)
        Me.btnAddRev.Name = "btnAddRev"
        Me.btnAddRev.Size = New System.Drawing.Size(75, 23)
        Me.btnAddRev.TabIndex = 7
        Me.btnAddRev.Text = "Add Rev"
        Me.btnAddRev.UseVisualStyleBackColor = True
        '
        'dgvRev1
        '
        Me.dgvRev1.AllowUserToAddRows = False
        Me.dgvRev1.AllowUserToDeleteRows = False
        Me.dgvRev1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill
        Me.dgvRev1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvRev1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Rev1Item, Me.Rev1Drawing, Me.Rev1IsDirty})
        Me.dgvRev1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter
        Me.dgvRev1.Location = New System.Drawing.Point(6, 19)
        Me.dgvRev1.Name = "dgvRev1"
        Me.dgvRev1.RowHeadersVisible = False
        Me.dgvRev1.Size = New System.Drawing.Size(326, 312)
        Me.dgvRev1.TabIndex = 17
        '
        'Rev1Item
        '
        Me.Rev1Item.HeaderText = "Item"
        Me.Rev1Item.Name = "Rev1Item"
        Me.Rev1Item.ReadOnly = True
        Me.Rev1Item.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Rev1Item.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        '
        'Rev1Drawing
        '
        Me.Rev1Drawing.HeaderText = "Value"
        Me.Rev1Drawing.Name = "Rev1Drawing"
        '
        'Rev1IsDirty
        '
        Me.Rev1IsDirty.HeaderText = "IsDirty"
        Me.Rev1IsDirty.Name = "Rev1IsDirty"
        Me.Rev1IsDirty.Visible = False
        '
        'lblRev0
        '
        Me.lblRev0.AutoSize = True
        Me.lblRev0.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRev0.Location = New System.Drawing.Point(6, 3)
        Me.lblRev0.Name = "lblRev0"
        Me.lblRev0.Size = New System.Drawing.Size(307, 13)
        Me.lblRev0.TabIndex = 0
        Me.lblRev0.Text = "Changes here overwrite the revision table, proceed with caution" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'cmsCustom
        '
        Me.cmsCustom.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RemoveIPropertyToolStripMenuItem})
        Me.cmsCustom.Name = "ContextMenuStrip1"
        Me.cmsCustom.Size = New System.Drawing.Size(169, 26)
        '
        'RemoveIPropertyToolStripMenuItem
        '
        Me.RemoveIPropertyToolStripMenuItem.Name = "RemoveIPropertyToolStripMenuItem"
        Me.RemoveIPropertyToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.RemoveIPropertyToolStripMenuItem.Text = "Remove iProperty"
        '
        'ProgressBar2
        '
        Me.ProgressBar2.Location = New System.Drawing.Point(12, 442)
        Me.ProgressBar2.Name = "ProgressBar2"
        Me.ProgressBar2.Size = New System.Drawing.Size(185, 23)
        Me.ProgressBar2.TabIndex = 6
        Me.ProgressBar2.Visible = False
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.HeaderText = "Item"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.ReadOnly = True
        Me.DataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn1.Width = 108
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.HeaderText = "Model"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.ReadOnly = True
        Me.DataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn2.Visible = False
        Me.DataGridViewTextBoxColumn2.Width = 107
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.HeaderText = "Drawing"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn3.Width = 108
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.HeaderText = "Item"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.ReadOnly = True
        Me.DataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn4.Visible = False
        Me.DataGridViewTextBoxColumn4.Width = 108
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.HeaderText = "Model"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.ReadOnly = True
        Me.DataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn5.Width = 107
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.HeaderText = "Drawing"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 108
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.HeaderText = "Item"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.ReadOnly = True
        Me.DataGridViewTextBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn7.Visible = False
        Me.DataGridViewTextBoxColumn7.Width = 108
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.HeaderText = "Model"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.ReadOnly = True
        Me.DataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn8.Visible = False
        Me.DataGridViewTextBoxColumn8.Width = 107
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.HeaderText = "Drawing"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.ReadOnly = True
        Me.DataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn9.Width = 108
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.ReadOnly = True
        Me.DataGridViewTextBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn10.Visible = False
        Me.DataGridViewTextBoxColumn10.Width = 108
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.HeaderText = "Value"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.Visible = False
        Me.DataGridViewTextBoxColumn11.Width = 107
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.ReadOnly = True
        Me.DataGridViewTextBoxColumn12.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn12.Visible = False
        Me.DataGridViewTextBoxColumn12.Width = 108
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.HeaderText = "Value"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.Width = 107
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.HeaderText = "IsDirty"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.Visible = False
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.ReadOnly = True
        Me.DataGridViewTextBoxColumn15.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn15.Width = 108
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.ReadOnly = True
        Me.DataGridViewTextBoxColumn16.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn16.Width = 108
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.HeaderText = "IsDirty"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.Visible = False
        Me.DataGridViewTextBoxColumn17.Width = 107
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.HeaderText = "Value"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.ReadOnly = True
        Me.DataGridViewTextBoxColumn18.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn18.Visible = False
        Me.DataGridViewTextBoxColumn18.Width = 107
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.HeaderText = "Item"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        Me.DataGridViewTextBoxColumn19.ReadOnly = True
        Me.DataGridViewTextBoxColumn19.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn19.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn19.Width = 162
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.HeaderText = "IsDirty"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.Visible = False
        Me.DataGridViewTextBoxColumn20.Width = 161
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.HeaderText = "Drawing"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        Me.DataGridViewTextBoxColumn21.Visible = False
        Me.DataGridViewTextBoxColumn21.Width = 161
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.HeaderText = "Item"
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        Me.DataGridViewTextBoxColumn22.ReadOnly = True
        Me.DataGridViewTextBoxColumn22.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn22.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn22.Width = 108
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.HeaderText = "Model"
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        Me.DataGridViewTextBoxColumn23.ReadOnly = True
        Me.DataGridViewTextBoxColumn23.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn23.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn23.Visible = False
        Me.DataGridViewTextBoxColumn23.Width = 107
        '
        'DataGridViewTextBoxColumn24
        '
        Me.DataGridViewTextBoxColumn24.HeaderText = "Drawing"
        Me.DataGridViewTextBoxColumn24.Name = "DataGridViewTextBoxColumn24"
        Me.DataGridViewTextBoxColumn24.Visible = False
        Me.DataGridViewTextBoxColumn24.Width = 108
        '
        'DataGridViewTextBoxColumn34
        '
        Me.DataGridViewTextBoxColumn34.HeaderText = "Drawing"
        Me.DataGridViewTextBoxColumn34.Name = "DataGridViewTextBoxColumn34"
        Me.DataGridViewTextBoxColumn34.Width = 108
        '
        'DataGridViewTextBoxColumn35
        '
        Me.DataGridViewTextBoxColumn35.HeaderText = "Item"
        Me.DataGridViewTextBoxColumn35.Name = "DataGridViewTextBoxColumn35"
        Me.DataGridViewTextBoxColumn35.ReadOnly = True
        Me.DataGridViewTextBoxColumn35.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn35.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn35.Width = 108
        '
        'DataGridViewTextBoxColumn36
        '
        Me.DataGridViewTextBoxColumn36.HeaderText = "Model"
        Me.DataGridViewTextBoxColumn36.Name = "DataGridViewTextBoxColumn36"
        Me.DataGridViewTextBoxColumn36.ReadOnly = True
        Me.DataGridViewTextBoxColumn36.Resizable = System.Windows.Forms.DataGridViewTriState.[False]
        Me.DataGridViewTextBoxColumn36.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.DataGridViewTextBoxColumn36.Width = 107
        '
        'DataGridViewTextBoxColumn37
        '
        Me.DataGridViewTextBoxColumn37.HeaderText = "Drawing"
        Me.DataGridViewTextBoxColumn37.Name = "DataGridViewTextBoxColumn37"
        Me.DataGridViewTextBoxColumn37.Width = 108
        '
        'iProperties
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(369, 477)
        Me.Controls.Add(Me.ProgressBar2)
        Me.Controls.Add(Me.btnOK)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.iProp)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "iProperties"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "iProperties"
        Me.iProp.ResumeLayout(False)
        Me.Summary.ResumeLayout(False)
        CType(Me.dgvSummary, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Project.ResumeLayout(False)
        CType(Me.dgvProject, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Status.ResumeLayout(False)
        CType(Me.dgvStatus, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Custom.ResumeLayout(False)
        Me.Custom.PerformLayout()
        CType(Me.dgvCustomDrawing, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgvCustomModel, System.ComponentModel.ISupportInitialize).EndInit()
        Me.RevisionTable.ResumeLayout(False)
        Me.RevisionTabs.ResumeLayout(False)
        Me.Rev1.ResumeLayout(False)
        Me.Rev1.PerformLayout()
        CType(Me.dgvRev1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.cmsCustom.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnOK As System.Windows.Forms.Button
    Friend WithEvents btnCancel As System.Windows.Forms.Button
    Friend WithEvents iProp As System.Windows.Forms.TabControl
    Friend WithEvents Summary As System.Windows.Forms.TabPage
    Friend WithEvents Project As System.Windows.Forms.TabPage
    Friend WithEvents Status As System.Windows.Forms.TabPage
    Friend WithEvents Custom As System.Windows.Forms.TabPage
    Friend WithEvents RevisionTable As System.Windows.Forms.TabPage
    Friend WithEvents RevisionTabs As System.Windows.Forms.TabControl
    Friend WithEvents Rev1 As System.Windows.Forms.TabPage
    Friend WithEvents lblRev0 As System.Windows.Forms.Label
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents ProgressBar2 As System.Windows.Forms.ProgressBar
    Friend WithEvents dgvSummary As Windows.Forms.DataGridView
    Friend WithEvents dgvProject As Windows.Forms.DataGridView
    Friend WithEvents dgvStatus As Windows.Forms.DataGridView
    Friend WithEvents dgvCustomModel As Windows.Forms.DataGridView
    Friend WithEvents dgvRev1 As Windows.Forms.DataGridView
    Friend WithEvents dgvCustomDrawing As Windows.Forms.DataGridView
    Friend WithEvents Label2 As Windows.Forms.Label
    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents DataGridViewTextBoxColumn1 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn34 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn35 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn36 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn37 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btnAddRev As Windows.Forms.Button
    Friend WithEvents ProjItem As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProjModel As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProjDrawing As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ProjectIsDirty As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn24 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StatusItem As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StatusModel As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StatusDrawing As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents StatusIsDirty As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SumItem As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SumModel As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SumDrawing As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SummaryIsDirty As Windows.Forms.DataGridViewCheckBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Rev1Item As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Rev1Drawing As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Rev1IsDirty As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cmsCustom As Windows.Forms.ContextMenuStrip
    Friend WithEvents RemoveIPropertyToolStripMenuItem As Windows.Forms.ToolStripMenuItem
    Friend WithEvents DCusName As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DCusValue As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DCusType As Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents DrawingIsDirty As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PCusName As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PCusValue As Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PCusType As Windows.Forms.DataGridViewComboBoxColumn
    Friend WithEvents ModelIsDirty As Windows.Forms.DataGridViewTextBoxColumn
End Class
